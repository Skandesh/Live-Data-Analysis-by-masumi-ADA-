# Live Data Analysis by Masumi (ADA)
AI-driven cybersecurity policy analyzer with on-chain ADA micropayments.
See `backend/app.py` for API and `frontend/index.html` for web interface.
